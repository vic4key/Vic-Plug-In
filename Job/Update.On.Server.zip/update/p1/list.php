<?php
	define("FILE_DIR","/files/");
	$crDir = ".".FILE_DIR;
	
	$myDir = opendir($crDir);
	
	while ($entryName = readdir($myDir)) {
		$dirArray[] = $entryName;
	}
	
	closedir($myDir);

	sort($dirArray);

	$count = count($dirArray);

	printf("<files>");
	for($i = 0; $i < $count; $i++) {
		$name = $dirArray[$i];
		if (strcmp($name, ".") == 0 || strcmp($name, "..") == 0) continue;
		printf("<file>", $i);
		printf("<name>%s</name>", $name);
		printf("<size>%d</size>", filesize($crDir.$name));
		printf("</file>");
	}
	
	printf("</files>");
?>